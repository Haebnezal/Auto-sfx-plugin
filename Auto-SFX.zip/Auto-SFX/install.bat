@echo off
setlocal EnableExtensions
title Auto SFX - Install
cd /d "%~dp0"

set "DEST=%APPDATA%\Adobe\CEP\extensions\com.habil.autosfx"

echo Enabling unsigned CEP extensions (PlayerDebugMode) for CSXS 10 to 12 ...
for %%C in (9 10 11 12) do reg add "HKCU\Software\Adobe\CSXS.%%C" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

echo Copying the extension to:
echo   %DEST%
if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%"
robocopy "cep" "%DEST%" /E /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo [ERROR] Copy failed.
  pause
  exit /b 1
)

echo.
echo Installed. Restart Premiere Pro, then open Window ^> Extensions ^> Auto SFX.
pause
exit /b 0
