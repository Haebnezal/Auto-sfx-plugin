// Auto SFX – sound library panel.
// Folders, favourites and categories; waveform previews with the peak marked;
// Insert places the sound so its peak lands on the playhead (CTI).
(function () {
  var AUDIO_EXT = ["wav", "mp3", "aif", "aiff", "m4a"];
  var ROOTS_KEY = "autosfx.roots";
  var FAV_KEY = "autosfx.favorites";
  var CAT_KEY = "autosfx.categories";
  var BINS = 120;

  var fs = window.cep && window.cep.fs;
  var nodeFs = null, nodePath = null;
  try { nodeFs = require("fs"); nodePath = require("path"); } catch (e) { /* no Node */ }
  var bridge = window.AutoSFXCEP;
  var $ = function (id) { return document.getElementById(id); };

  // ---------- Storage ----------
  function load(key, fallback) {
    try { var v = JSON.parse(localStorage.getItem(key)); return v === null ? fallback : v; }
    catch (e) { return fallback; }
  }
  function save(key, value) { localStorage.setItem(key, JSON.stringify(value)); }

  var roots = load(ROOTS_KEY, []);
  var favorites = load(FAV_KEY, {});          // path -> { name, category }
  var categories = load(CAT_KEY, ["General"]); // user categories

  // ---------- File helpers ----------
  function isAudio(name) {
    var i = name.lastIndexOf(".");
    return i > 0 && AUDIO_EXT.indexOf(name.slice(i + 1).toLowerCase()) !== -1;
  }
  function joinPath(a, b) {
    var sep = a.indexOf("\\") !== -1 ? "\\" : "/";
    return a.replace(/[\\\/]+$/, "") + sep + b;
  }
  function baseName(p) { return p.split(/[\\\/]/).pop() || p; }
  function toFileUrl(p) { return "file:///" + encodeURI(p.replace(/\\/g, "/").replace(/^\/+/, "")); }
  function natural(a, b) { return a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }); }

  function readLevel(dir) {
    var res = fs.readdir(dir);
    var folders = [], files = [];
    if (res.err) return { folders: folders, files: files };
    res.data.forEach(function (name) {
      var full = joinPath(dir, name);
      var st = fs.stat(full);
      if (st.err) return;
      if (st.data.isDirectory()) folders.push({ name: name, path: full });
      else if (isAudio(name)) files.push({ name: name, path: full });
    });
    folders.sort(function (a, b) { return natural(a.name, b.name); });
    files.sort(function (a, b) { return natural(a.name, b.name); });
    return { folders: folders, files: files };
  }
  function collectAudio(dir, depth) {
    depth = depth || 0;
    var lvl = readLevel(dir);
    var all = lvl.files.slice();
    if (depth < 10) lvl.folders.forEach(function (f) { all = all.concat(collectAudio(f.path, depth + 1)); });
    return all;
  }

  // ---------- Waveform and peak analysis ----------
  // peaks[path] = { env: [BINS floats 0..1], peakSec, duration } or { error: true }
  var peaks = {};
  var AudioCtx = window.AudioContext || window.webkitAudioContext;
  var ctx = null;
  var queue = [], queueBusy = false;

  function analyzeFile(path, done) {
    if (peaks[path]) return done(peaks[path]);
    if (!nodeFs || !AudioCtx) { peaks[path] = { error: true }; return done(peaks[path]); }
    try {
      var buf = nodeFs.readFileSync(path);
      var ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
      if (!ctx) ctx = new AudioCtx();
      ctx.decodeAudioData(ab, function (decoded) {
        var data = decoded.getChannelData(0);
        var n = data.length, step = Math.max(1, Math.floor(n / BINS));
        var env = [], best = 0, bestIdx = 0, max = 0;
        for (var b = 0; b < BINS; b++) {
          var start = b * step, end = Math.min(n, start + step), m = 0;
          for (var i = start; i < end; i++) {
            var v = Math.abs(data[i]);
            if (v > m) m = v;
            if (v > best) { best = v; bestIdx = i; }
          }
          env.push(m);
          if (m > max) max = m;
        }
        if (max > 0) env = env.map(function (x) { return x / max; });
        peaks[path] = { env: env, peakSec: bestIdx / decoded.sampleRate, duration: decoded.duration };
        done(peaks[path]);
      }, function () {
        peaks[path] = { error: true };
        done(peaks[path]);
      });
    } catch (e) {
      peaks[path] = { error: true };
      done(peaks[path]);
    }
  }

  // Decode one file at a time so large libraries stay responsive.
  function queueAnalyze(path, done) {
    queue.push({ path: path, done: done });
    pumpQueue();
  }
  function pumpQueue() {
    if (queueBusy || !queue.length) return;
    queueBusy = true;
    var job = queue.shift();
    analyzeFile(job.path, function (res) {
      queueBusy = false;
      job.done(res);
      pumpQueue();
    });
  }

  function sizeCanvas(canvas) {
    var dpr = window.devicePixelRatio || 1;
    var w = Math.max(60, canvas.clientWidth || 300);
    var h = Math.max(20, canvas.clientHeight || 34);
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    var c = canvas.getContext ? canvas.getContext("2d") : null;
    if (c) c.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  // Redraw every visible waveform at the current size (called when the panel is resized).
  function redrawWaves() {
    var list = document.querySelectorAll("canvas.wave-canvas");
    for (var i = 0; i < list.length; i++) {
      var cv = list[i];
      sizeCanvas(cv);
      var path = cv.getAttribute("data-path");
      drawWave(cv, peaks[path] && peaks[path].env ? peaks[path] : null);
    }
  }

  function drawWave(canvas, res) {
    var c = canvas.getContext ? canvas.getContext("2d") : null;
    if (!c) return;
    var dpr = window.devicePixelRatio || 1;
    var w = canvas.width / dpr, h = canvas.height / dpr;
    c.clearRect(0, 0, w, h);
    var bars = res && res.env ? res.env : null;
    var barW = w / BINS;
    for (var i = 0; i < BINS; i++) {
      var v = bars ? bars[i] : 0.12;
      var bh = Math.max(2, v * (h - 6));
      var x = i * barW;
      var grad = c.createLinearGradient(0, (h - bh) / 2, 0, (h + bh) / 2);
      grad.addColorStop(0, bars ? "#7CFFB2" : "#2F4A39");
      grad.addColorStop(1, bars ? "#00B85C" : "#1B2C22");
      c.fillStyle = grad;
      c.fillRect(x + 0.5, (h - bh) / 2, Math.max(1, barW - 1.5), bh);
    }
    if (bars && res.peakSec !== undefined && res.duration) {
      var px = (res.peakSec / res.duration) * w;
      c.fillStyle = "#FFFFFF";
      c.fillRect(Math.min(w - 2, px), 0, 2, h);
    }
  }

  // ---------- Library state ----------
  var trees = [];
  var view = { kind: "folder", node: null };   // or { kind: "fav", category: name|null }
  var chosen = null;                            // { path, name }
  var preview = new Audio();
  var previewRow = null;

  function makeNode(name, path, isRoot) {
    return { name: name, path: path, isRoot: !!isRoot, expanded: false, children: null };
  }
  function childrenOf(node) {
    if (node.children === null) {
      node.children = readLevel(node.path).folders.map(function (f) { return makeNode(f.name, f.path, false); });
    }
    return node.children;
  }

  // ---------- Left column: favourites and categories ----------
  function renderCategories() {
    var el = $("categoryList");
    el.innerHTML = "";
    var entries = Object.keys(favorites);
    function row(label, count, catValue) {
      var d = document.createElement("div");
      var active = view.kind === "fav" && view.category === catValue;
      d.className = "cat" + (active ? " active" : "");
      var l = document.createElement("span");
      l.textContent = label;
      var c = document.createElement("span");
      c.className = "cat-count";
      c.textContent = count;
      d.appendChild(l);
      d.appendChild(c);
      d.addEventListener("click", function () { showFavorites(catValue); });
      el.appendChild(d);
    }
    row("★ All favourites", entries.length, null);
    categories.forEach(function (cat) {
      var n = entries.filter(function (p) { return favorites[p].category === cat; }).length;
      row(cat, n, cat);
    });
  }

  function refreshCategorySelect(selected) {
    var sel = $("categorySelect");
    sel.innerHTML = "";
    categories.forEach(function (cat) {
      var o = document.createElement("option");
      o.value = cat;
      o.textContent = cat;
      if (cat === selected) o.selected = true;
      sel.appendChild(o);
    });
  }

  // ---------- Tree (folders) ----------
  function renderTree() {
    var el = $("tree");
    el.innerHTML = "";
    if (!trees.length) {
      var hint = document.createElement("div");
      hint.className = "empty";
      hint.textContent = "No sound folders yet. Press + to add one.";
      el.appendChild(hint);
      return;
    }
    trees.forEach(function (t) { walk(t, 0, el); });
  }
  function walk(node, depth, container) {
    var row = document.createElement("div");
    var isSel = view.kind === "folder" && view.node && view.node.path === node.path;
    row.className = "tree-row" + (node.isRoot ? " root" : "") + (isSel ? " selected" : "");
    row.style.paddingLeft = (8 + depth * 14) + "px";
    row.title = node.path;
    var icon = document.createElement("span");
    icon.className = "tree-icon";
    icon.textContent = node.expanded ? "▾" : "▸";
    var label = document.createElement("span");
    label.textContent = node.name;
    row.appendChild(icon);
    row.appendChild(label);
    row.addEventListener("click", function (ev) {
      ev.stopPropagation();
      node.expanded = !node.expanded;
      if (node.expanded) childrenOf(node);
      showFolder(node);
    });
    container.appendChild(row);
    if (node.expanded && node.children) node.children.forEach(function (c) { walk(c, depth + 1, container); });
  }

  // ---------- Right column: sound rows ----------
  function setChosen(item) {
    chosen = item;
    $("chosenName").textContent = item ? item.name : "Nothing selected";
    $("insertBtn").disabled = !item;
    if (item) {
      var fav = favorites[item.path];
      refreshCategorySelect(fav ? fav.category : categories[0]);
      $("insertStatus").textContent = fav
        ? "Category: " + fav.category + " · Insert places the peak on the playhead"
        : "Insert places the peak on the playhead · ★ to favourite";
    }
  }

  function toggleFavorite(item, category) {
    if (favorites[item.path]) {
      delete favorites[item.path];
    } else {
      favorites[item.path] = { name: item.name, category: category || categories[0] };
    }
    save(FAV_KEY, favorites);
    renderCategories();
    renderList();
  }

  function makeRow(item, extraTag) {
    var row = document.createElement("div");
    var isChosen = chosen && chosen.path === item.path;
    row.className = "sound" + (isChosen ? " chosen" : "");
    var fav = favorites[item.path];

    var star = document.createElement("button");
    star.className = "star" + (fav ? " on" : "");
    star.textContent = fav ? "★" : "☆";
    star.title = fav ? "Remove from favourites" : "Add to favourites";
    star.addEventListener("click", function (ev) {
      ev.stopPropagation();
      toggleFavorite(item, categories[0]);
    });

    var meta = document.createElement("div");
    meta.className = "sound-meta";
    var name = document.createElement("span");
    name.className = "sound-name";
    name.textContent = item.name;
    var rel = document.createElement("span");
    rel.className = "sound-path";
    rel.textContent = item.path;
    meta.appendChild(name);
    meta.appendChild(rel);

    var canvas = document.createElement("canvas");
    canvas.className = "wave-canvas";
    canvas.setAttribute("data-path", item.path);
    sizeCanvas(canvas);
    drawWave(canvas, peaks[item.path] && peaks[item.path].env ? peaks[item.path] : null);
    queueAnalyze(item.path, function (res) { drawWave(canvas, res); });

    var right = document.createElement("div");
    right.className = "tag-slot";
    right.style.display = "flex";
    right.style.gap = "6px";
    right.style.alignItems = "center";
    if (fav) {
      var tag = document.createElement("span");
      tag.className = "tag";
      tag.textContent = fav.category;
      right.appendChild(tag);
    }
    if (extraTag) right.appendChild(extraTag);

    row.appendChild(star);
    row.appendChild(meta);
    row.appendChild(canvas);
    row.appendChild(right);

    row.addEventListener("mouseenter", function () { play(item, row); });
    row.addEventListener("mouseleave", stopPreview);
    row.addEventListener("click", function () {
      setChosen(item);
      renderList();
    });
    return row;
  }

  function renderList() {
    var list = $("soundList");
    list.innerHTML = "";
    if (view.kind === "folder") {
      if (!view.node) return;
      $("viewTitle").textContent = view.node.name;
      // Group by folder: sort by full path so sounds from the same subfolder sit together
      var items = collectAudio(view.node.path).sort(function (a, b) { return natural(a.path, b.path); });
      $("viewSub").textContent = items.length + " sounds · " + view.node.path;
      if (!items.length) list.appendChild(emptyNote("No audio files in this folder."));
      items.forEach(function (it) { list.appendChild(makeRow(it)); });
    } else {
      var title = view.category ? view.category : "All favourites";
      $("viewTitle").textContent = "★ " + title;
      var paths = Object.keys(favorites).filter(function (p) {
        return !view.category || favorites[p].category === view.category;
      });
      $("viewSub").textContent = paths.length + " favourite sounds";
      if (!paths.length) list.appendChild(emptyNote("No favourites here yet. Press ☆ on any sound."));
      paths.sort(function (a, b) { return natural(favorites[a].name, favorites[b].name); });
      paths.forEach(function (p) {
        var item = { path: p, name: favorites[p].name };
        if (!fs.stat(p).err) list.appendChild(makeRow(item));
      });
    }
  }

  function emptyNote(text) {
    var d = document.createElement("div");
    d.className = "empty";
    d.textContent = text;
    return d;
  }

  function showFolder(node) {
    if (document.body.classList.contains("is-narrow")) setMobileView("sounds");
    view = { kind: "folder", node: { name: node.name, path: node.path } };
    setChosen(null);
    renderTree();
    renderCategories();
    renderList();
  }
  function showFavorites(category) {
    if (document.body.classList.contains("is-narrow")) setMobileView("sounds");
    view = { kind: "fav", category: category };
    setChosen(null);
    renderTree();
    renderCategories();
    renderList();
  }

  // ---------- Preview ----------
  function play(item, row) {
    stopPreview();
    preview.src = toFileUrl(item.path);
    previewRow = row;
    row.classList.add("playing");
    var p = preview.play();
    if (p && p.catch) p.catch(function () {});
  }
  function stopPreview() {
    preview.pause();
    if (previewRow) previewRow.classList.remove("playing");
    previewRow = null;
  }

  // ---------- Folders ----------
  function addRoot(p) {
    if (!p || roots.indexOf(p) !== -1) return;
    roots.push(p);
    save(ROOTS_KEY, roots);
    trees.push(makeNode(baseName(p), p, true));
    showFolder(trees[trees.length - 1]);
    $("statusLine").textContent = roots.length + " sound folder(s) connected";
    $("removeFolderBtn").disabled = false;
  }
  function removeRoot(p) {
    roots = roots.filter(function (r) { return r !== p; });
    trees = trees.filter(function (t) { return t.path !== p; });
    save(ROOTS_KEY, roots);
    view = { kind: "folder", node: null };
    setChosen(null);
    $("removeFolderBtn").disabled = true;
    $("statusLine").textContent = roots.length ? roots.length + " sound folder(s) connected" : "Add a sound folder to begin";
    renderTree();
    $("soundList").innerHTML = "";
    $("viewTitle").textContent = "Select a folder";
    $("viewSub").textContent = "";
  }

  $("addFolderBtn").addEventListener("click", function () {
    bridge.evalScript("selectFolder()", function (p) { if (p) addRoot(p); });
  });
  $("removeFolderBtn").addEventListener("click", function () {
    if (view.kind === "folder" && view.node && roots.indexOf(view.node.path) !== -1) removeRoot(view.node.path);
  });

  // ---------- Categories ----------
  $("addCategoryBtn").addEventListener("click", function () {
    var name = window.prompt("New category name:", "");
    if (!name) return;
    name = name.trim();
    if (!name || categories.indexOf(name) !== -1) return;
    categories.push(name);
    save(CAT_KEY, categories);
    renderCategories();
    refreshCategorySelect(name);
  });

  $("categorySelect").addEventListener("change", function () {
    if (!chosen) return;
    var cat = this.value;
    if (favorites[chosen.path]) {
      favorites[chosen.path].category = cat;
    } else {
      favorites[chosen.path] = { name: chosen.name, category: cat };
    }
    save(FAV_KEY, favorites);
    renderCategories();
    renderList();
    $("insertStatus").textContent = "Category set to " + cat;
  });

  // ---------- Level (gain) ----------
  var GAIN_KEY = "autosfx.gain.v3";
  var DEFAULT_GAIN_DB = 0;
  var gainDb = load(GAIN_KEY, DEFAULT_GAIN_DB);
  function showGain() {
    $("gainRange").value = gainDb;
    $("gainVal").textContent = (gainDb > 0 ? "+" : "") + gainDb.toFixed(1) + " dB";
  }
  $("gainRange").addEventListener("input", function () {
    gainDb = parseFloat(this.value);
    save(GAIN_KEY, gainDb);
    showGain();
  });
  $("gainApplyBtn").addEventListener("click", function () {
    bridge.evalScript("applyGainToSelection(" + gainDb + ")", function (r) {
      var msg = {
        NO_SELECTION_API: "This Premiere version cannot read the timeline selection.",
        NO_SELECTION: "Select clips on the timeline first.",
        NO_SEQUENCE: "Open a sequence first."
      };
      if (r.indexOf("OK:") === 0) $("insertStatus").textContent = "Level " + gainDb + " dB applied to " + r.slice(3) + " clip(s)";
      else $("insertStatus").textContent = msg[r] || ("Error: " + r);
    });
  });
  showGain();

  // ---------- Insert: peak on CTI, only on empty or sound-effect tracks ----------
  $("insertBtn").addEventListener("click", function () {
    if (!chosen) return;
    var item = chosen;
    $("insertBtn").disabled = true;
    $("insertStatus").textContent = "Analysing…";
    queueAnalyze(item.path, function (res) {
      bridge.evalScript("getPlayheadSeconds()", function (sec) {
        var playhead = parseFloat(sec);
        if (isNaN(playhead) || playhead < 0) {
          $("insertBtn").disabled = false;
          $("insertStatus").textContent = "No active sequence";
          return;
        }
        var peakSec = res && res.peakSec !== undefined ? res.peakSec : 0;
        var duration = res && res.duration ? res.duration : 2;
        var start = playhead - peakSec;
        var note = "";
        if (start < 0) { start = 0; note = " (peak before 0, placed at 0)"; }
        var rootsArg = JSON.stringify(roots.join("|"));
        var code = "insertSoundSmart(" + JSON.stringify(item.path) + "," + start + "," + duration + "," +
          rootsArg + "," + gainDb + ")";
        bridge.evalScript(code, function (r) {
          $("insertBtn").disabled = false;
          if (r.indexOf("OK:") === 0) {
            var parts = r.split(":");
            var track = parseInt(parts[1], 10) + 1;
            var gainNote = parts[2] === "NO_GAIN" ? " · level NOT set, see debug log" : " · " + gainDb + " dB";
            $("insertStatus").textContent = "Inserted " + item.name + " on A" + track + gainNote + note;
          } else if (r.indexOf("NO_FREE_TRACK") === 0) {
            var detail = r.split("|")[1] || "";
            $("insertStatus").textContent = "No free sound track here. " + detail +
              " · details: %TEMP%\\autosfx-debug.log";
          } else {
            $("insertStatus").textContent = "Error: " + r;
          }
        });
      });
    });
  });

  // ---------- Drawer ----------
  function setDrawer(open) {
    $("drawer").classList.toggle("open", open);
    $("drawerBackdrop").classList.toggle("open", open);
    $("drawer").setAttribute("aria-hidden", open ? "false" : "true");
  }
  $("menuBtn").addEventListener("click", function () { setDrawer(true); });
  $("closeDrawer").addEventListener("click", function () { setDrawer(false); });
  $("drawerBackdrop").addEventListener("click", function () { setDrawer(false); });

  // ---------- Responsive size classes ----------
  // The panel can be resized to any size. Breakpoints are applied as classes on <body>
  // so CSS can switch layout (ResizeObserver is available in CEP's Chromium).
  function setMobileView(v) {
    var b = document.body.classList;
    b.toggle("view-library", v === "library");
    b.toggle("view-sounds", v === "sounds");
    $("viewLibraryBtn").classList.toggle("active", v === "library");
    $("viewSoundsBtn").classList.toggle("active", v === "sounds");
  }
  $("viewLibraryBtn").addEventListener("click", function () { setMobileView("library"); });
  $("viewSoundsBtn").addEventListener("click", function () { setMobileView("sounds"); });
  setMobileView("sounds");

  // While the panel is being resized, heavy effects are switched off (see .is-resizing in CSS).
  // Work is done once per frame and the waveforms are redrawn once, when resizing settles.
  var resizeTimer = null, pendingWidth = null, frame = null;
  function applySizeClasses(width) {
    var b = document.body.classList;
    b.toggle("is-narrow", width < 760);
    b.toggle("is-tiny", width < 480);
  }
  function onResize(width) {
    pendingWidth = width;
    if (frame) return;
    frame = window.requestAnimationFrame(function () {
      frame = null;
      applySizeClasses(pendingWidth);
    });
    document.body.classList.add("is-resizing");
    if (resizeTimer) clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      resizeTimer = null;
      document.body.classList.remove("is-resizing");
      redrawWaves();
    }, 140);
  }
  if (window.ResizeObserver) {
    new ResizeObserver(function (entries) {
      onResize(entries[0].contentRect.width);
    }).observe(document.body);
  }
  applySizeClasses(window.innerWidth || 860);
  setTimeout(redrawWaves, 0);

  // ---------- Init ----------
  roots = roots.filter(function (p) { return fs && !fs.stat(p).err; });
  trees = roots.map(function (p) { return makeNode(baseName(p), p, true); });
  if (roots.length) {
    $("statusLine").textContent = roots.length + " sound folder(s) connected";
    $("removeFolderBtn").disabled = false;
    showFolder(trees[0]);
  } else {
    renderTree();
    renderCategories();
  }
  renderCategories();
})();
