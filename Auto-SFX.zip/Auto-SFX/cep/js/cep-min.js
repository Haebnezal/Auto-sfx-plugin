// Minimal CEP bridge.
(function () {
  window.AutoSFXCEP = {
    evalScript: function (script, callback) {
      if (!window.__adobe_cep__) { if (callback) callback("NO_CEP"); return; }
      window.__adobe_cep__.evalScript(script, callback || function () {});
    },
    extensionPath: function () {
      if (!window.__adobe_cep__) return "";
      var p = window.__adobe_cep__.getSystemPath("extension");
      return String(p).replace(/^file:\/\/\/?/, "").replace(/^\/(?=[A-Za-z]:)/, "");
    }
  };
})();
