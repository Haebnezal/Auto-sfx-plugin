// Auto SFX – ExtendScript host (ES3: no JSON, let/const, arrows).

function selectFolder() {
  var f = Folder.selectDialog("Choose a sound effects folder");
  return f ? f.fsName : "";
}

function findRootItemByName(name) {
  var kids = app.project.rootItem.children;
  for (var i = 0; i < kids.numItems; i++) {
    if (kids[i].name === name) return kids[i];
  }
  return null;
}

// Imports the file if needed and inserts it on an audio track at `seconds` (0-based track index).
function insertSound(path, seconds, audioTrackIndex) {
  if (!app.project) return "NO_PROJECT";
  var seq = app.project.activeSequence;
  if (!seq) return "NO_SEQUENCE";
  var file = new File(path);
  if (!file.exists) return "NO_FILE";
  var item = findRootItemByName(file.name);
  if (!item) {
    app.project.importFiles([file.fsName], true, app.project.rootItem, false);
    item = findRootItemByName(file.name);
  }
  if (!item) return "IMPORT_FAILED";
  if (audioTrackIndex >= seq.audioTracks.numTracks) return "NO_TRACK";
  seq.audioTracks[audioTrackIndex].insertClip(item, seconds);
  return "OK";
}

function getPlayheadSeconds() {
  if (!app.project) return "-1";
  var seq = app.project.activeSequence;
  if (!seq) return "-1";
  return String(seq.getPlayerPosition().seconds);
}

// ---------- Smart insertion ----------
// Places a library sound on an audio track at `seconds`, lasting `duration` seconds.
// Tracks that hold any clip not from the sound library (dialogue, music, ambience) are skipped.
// Tracks that are empty or hold only library sounds are used, and only where the time range is free.
// Tracks that already hold library sounds are preferred, so sounds stack in sequence, not on top of each other.
// rootsStr: library folders joined with "|". gainDb: level applied after insertion.
function _normPath(p) {
  return String(p).replace(/\\/g, "/").toLowerCase();
}
function _isInRoots(path, roots) {
  var np = _normPath(path);
  for (var i = 0; i < roots.length; i++) {
    var nr = _normPath(roots[i]);
    if (nr.length && np.indexOf(nr) === 0) return true;
  }
  return false;
}

// Writes one line to Folder.temp/autosfx-debug.log so track decisions can be inspected in Premiere.
function _debugLog(line) {
  try {
    var f = new File(Folder.temp.fsName + "/autosfx-debug.log");
    f.open("a");
    f.writeln(new Date().toString() + "  " + line);
    f.close();
  } catch (e) { /* logging must never break insertion */ }
}

// ExtendScript (ES3) has no Array.prototype.indexOf, so use an explicit loop.
function _listHas(list, value) {
  for (var i = 0; i < list.length; i++) {
    if (list[i] === value) return true;
  }
  return false;
}

// Media paths of every clip on the video tracks. Audio tracks holding these files (the video's own
// audio) are never used for sound effects.
function _videoMediaPaths() {
  var out = [];
  var seq = app.project.activeSequence;
  for (var v = 0; v < seq.videoTracks.numTracks; v++) {
    var vt = seq.videoTracks[v];
    for (var k = 0; k < vt.clips.numItems; k++) {
      var c = vt.clips[k];
      var mp = c.projectItem ? c.projectItem.getMediaPath() : "";
      if (mp) out.push(_normPath(mp));
    }
  }
  return out;
}

function insertSoundSmart(path, seconds, duration, rootsStr, gainDb) {
  if (!app.project) return "NO_PROJECT";
  var seq = app.project.activeSequence;
  if (!seq) return "NO_SEQUENCE";
  var file = new File(path);
  if (!file.exists) return "NO_FILE";
  var item = findRootItemByName(file.name);
  if (!item) {
    app.project.importFiles([file.fsName], true, app.project.rootItem, false);
    item = findRootItemByName(file.name);
  }
  if (!item) return "IMPORT_FAILED";

  var roots = rootsStr ? rootsStr.split("|") : [];
  var videoPaths = _videoMediaPaths();
  var end = seconds + duration;
  var best = -1, bestRank = 99;
  var verdicts = [];
  var nTracks = seq.audioTracks.numTracks;

  for (var i = 0; i < nTracks; i++) {
    var tr = seq.audioTracks[i];
    var label = "A" + (i + 1);
    var nClips = tr.clips.numItems;

    // 1) A track that carries the video's own audio is never used.
    var isVideoAudio = false;
    var hasSfx = false;
    for (var j = 0; j < nClips; j++) {
      var mp = tr.clips[j].projectItem ? _normPath(tr.clips[j].projectItem.getMediaPath()) : "";
      if (mp && _listHas(videoPaths, mp)) { isVideoAudio = true; break; }
      if (mp && _isInRoots(mp, roots)) hasSfx = true;
    }
    if (isVideoAudio) { verdicts.push(label + ":video-audio"); continue; }

    // 2) Only clips that overlap the requested time range block the track.
    //    Clips far away on the same track do not matter.
    var blocker = "";
    for (var k = 0; k < nClips; k++) {
      var c2 = tr.clips[k];
      var overlaps = c2.start.seconds < end - 0.01 && c2.end.seconds > seconds + 0.01;
      if (!overlaps) continue;
      blocker = (c2.name || "clip") + " " + c2.start.seconds.toFixed(2) + "-" + c2.end.seconds.toFixed(2);
      break;
    }
    if (blocker) { verdicts.push(label + ":busy(" + blocker + ")"); continue; }

    verdicts.push(label + ":free(" + (hasSfx ? "sfx" : "empty") + ")");
    var rank = hasSfx ? 0 : 1;
    if (rank < bestRank) { best = i; bestRank = rank; }
  }

  _debugLog("insert " + file.name + " at " + seconds.toFixed(3) + "s dur " + duration.toFixed(3) +
    "s tracks=" + nTracks + " -> " + verdicts.join(", "));

  if (best < 0) return "NO_FREE_TRACK|" + verdicts.join(", ");

  var track = seq.audioTracks[best];
  track.insertClip(item, seconds);

  var inserted = null;
  for (var m = 0; m < track.clips.numItems; m++) {
    var cm = track.clips[m];
    if (Math.abs(cm.start.seconds - seconds) < 0.02 && cm.projectItem && cm.projectItem.name === file.name) {
      inserted = cm;
      break;
    }
  }
  var gainOk = inserted ? _applyGain(inserted, gainDb) : false;
  return "OK:" + best + (gainOk ? "" : ":NO_GAIN");
}

// Sets the Volume "Level" of one clip. Returns true when the parameter was found and set.
// Names are localised in non-English Premiere, so the Volume component is matched by matchName
// first, then by display name. Inside Volume, the "Level" parameter is the one that is not "Bypass".
function _applyGain(clip, db) {
  var linear = Math.pow(10, db / 20);
  for (var k = 0; k < clip.components.numItems; k++) {
    var comp = clip.components[k];
    var isVolume = (comp.matchName && String(comp.matchName).toLowerCase().indexOf("volume") !== -1) ||
                   comp.displayName === "Volume";
    if (!isVolume) continue;
    var target = _findLevelParam(comp);
    if (!target) { _debugLog("gain: Level parameter not found on " + clip.name); return false; }

    // Premiere builds differ on whether Level takes linear gain or dB. Try linear, read it back,
    // and fall back to dB if the value did not stick. The chosen mode is logged.
    target.setValue(linear, true);
    var back = Number(target.getValue());
    if (Math.abs(back - linear) < 0.01 * Math.max(1, Math.abs(linear))) {
      _debugLog("gain " + db + " dB set as linear " + linear.toFixed(4) + " (read back " + back.toFixed(4) + ")");
      return true;
    }
    target.setValue(db, true);
    var backDb = Number(target.getValue());
    if (Math.abs(backDb - db) < 0.1) {
      _debugLog("gain " + db + " dB set as dB (read back " + backDb.toFixed(2) + ")");
      return true;
    }
    _debugLog("gain: value did not stick (linear read " + back + ", dB read " + backDb + ")");
    return false;
  }
  _debugLog("gain: Volume component not found on clip " + clip.name);
  return false;
}

// The Level parameter of a Volume component. Names are localised, so match by matchName, then by
// display name, then fall back to the last non-bypass parameter (Volume is Bypass, then Level).
function _findLevelParam(comp) {
  var props = comp.properties;
  var target = null, fallback = null;
  for (var p = 0; p < props.numItems; p++) {
    var prop = props[p];
    var pm = prop.matchName ? String(prop.matchName).toLowerCase() : "";
    var pd = prop.displayName ? String(prop.displayName) : "";
    if (pm.indexOf("bypass") !== -1 || pd === "Bypass") continue;
    if (pm.indexOf("level") !== -1 || pd === "Level") target = prop;
    fallback = prop;
  }
  return target ? target : fallback;
}

// Applies a gain to the clips currently selected on the active sequence (if this Premiere build exposes it).
function applyGainToSelection(db) {
  var seq = app.project.activeSequence;
  if (!seq) return "NO_SEQUENCE";
  if (typeof seq.getSelection !== "function") return "NO_SELECTION_API";
  var sel = seq.getSelection();
  if (!sel || !sel.length) return "NO_SELECTION";
  var count = 0;
  for (var i = 0; i < sel.length; i++) {
    if (_applyGain(sel[i], db)) count++;
  }
  return "OK:" + count;
}

// Premiere version string (e.g. "14.0" for 2020, "15.0" for 2021, "25.x" for 2025).
function getHostVersion() {
  try { return String(app.version); } catch (e) { return "unknown"; }
}
