AUTO SFX 0.6.1 - Sound library for Adobe Premiere Pro

FOLDER CONTENTS
  INSTALL-GUIDE.txt  Step-by-step install guide (Persian)
  cep\               Extension source (CSXS, panel, scripts, assets)
  tools\             Put ZXPSignCmd.exe here (used only by make-zxp.bat)
  install.bat        Installs the extension for testing (no signing needed)
  uninstall.bat      Removes the installed extension
  make-zxp.bat       Builds a signed .zxp installer from cep\

INSTALL (Windows)
  1. Double-click install.bat.
  2. Restart Premiere Pro.
  3. Open Window > Extensions > Auto SFX.

USE
  Folders:    Press + to add a sound folder. Browse folders and subfolders on the left.
  Preview:    Hover a sound to hear it. Each row shows its waveform; the white line is the peak.
  Favourites: Press ☆ to add a sound to Favourites. Choose a category in the bottom bar.
              Press + next to Favourites to create a category.
  Insert:     Put the playhead where you want the sound's peak, select the sound, and press
              Insert at Playhead. The sound is placed so its peak lands on the playhead.
              Sounds go only on empty audio tracks or tracks that already hold library sounds.
              Tracks that carry the video's own audio are skipped. Other clips only block a track where they overlap the insert time. Overlapping sounds
              move to the next usable track, so sounds never stack on top of each other.
  Level:      The Level slider (default 0 dB) sets the volume of each inserted sound.
              "Apply to selected clips" changes the level of selected timeline clips.

BUILD A ZXP (Windows)
  1. Put ZXPSignCmd.exe into the tools folder.
  2. Double-click make-zxp.bat and enter a certificate password.
     The first run creates cert\auto-sfx.p12. Keep it: later builds must use the same certificate.
  3. The output is auto-sfx-<version>.zxp in this folder.

NOTES
  - The Level control writes the Volume "Level" parameter of the inserted clip. Some Premiere
    versions name or store this parameter differently. If the status shows "level not set",
    tell me your Premiere version and I will adapt the code.
  - install.bat turns on PlayerDebugMode so Premiere loads unsigned extensions.
  - Waveforms decode audio files with the Chromium audio engine. WAV, MP3 and M4A work; AIF may not
    decode in all setups, in which case the row shows a flat placeholder and insert still works
    (placed at the playhead).
