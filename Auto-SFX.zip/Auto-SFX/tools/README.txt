Put Adobe's ZXPSignCmd.exe in this folder (tools\ZXPSignCmd.exe).

Download: Adobe Exchange / Adobe ZXPSignCMD, or the "ZXPSignCMD" package from Adobe's developer tools.
make-zxp.bat looks for this exact file name.
