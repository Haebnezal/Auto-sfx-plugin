@echo off
setlocal EnableExtensions
title Auto SFX - Uninstall
set "DEST=%APPDATA%\Adobe\CEP\extensions\com.habil.autosfx"
if exist "%DEST%" (
  rmdir /s /q "%DEST%"
  echo Removed %DEST%
) else (
  echo Auto SFX is not installed.
)
pause
exit /b 0
