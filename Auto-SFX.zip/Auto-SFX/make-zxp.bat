@echo off
setlocal EnableExtensions
title Auto SFX - Build ZXP
cd /d "%~dp0"

set "SIGNER=tools\ZXPSignCmd.exe"
set "CEP_DIR=cep"
set "CERT=cert\auto-sfx.p12"

if not exist "%SIGNER%" (
  echo [ERROR] %SIGNER% not found.
  echo Place ZXPSignCmd.exe inside the tools folder and run this file again.
  pause
  exit /b 1
)

if not exist "%CEP_DIR%\CSXS\manifest.xml" (
  echo [ERROR] %CEP_DIR%\CSXS\manifest.xml not found.
  pause
  exit /b 1
)

for /f "usebackq delims=" %%v in (`powershell -NoProfile -Command "([xml](Get-Content '%CEP_DIR%\CSXS\manifest.xml')).ExtensionManifest.ExtensionBundleVersion"`) do set "VERSION=%%v"
if "%VERSION%"=="" set "VERSION=0.0.0"
set "OUT=auto-sfx-%VERSION%.zxp"

set /p "PASS=Certificate password: "
if "%PASS%"=="" (
  echo [ERROR] A password is required.
  pause
  exit /b 1
)

if not exist "cert" mkdir "cert"
if not exist "%CERT%" (
  echo No certificate found. Creating a self-signed certificate at %CERT% ...
  "%SIGNER%" -selfSignedCert US CA Habil "Auto SFX" "%PASS%" "%CERT%" -validityDays 3650
  if errorlevel 1 (
    echo [ERROR] Could not create the certificate.
    pause
    exit /b 1
  )
)

if exist "%OUT%" del /q "%OUT%"
echo Signing %CEP_DIR% into %OUT% ...
"%SIGNER%" -sign "%CEP_DIR%" "%OUT%" "%CERT%" "%PASS%"
if errorlevel 1 (
  echo [ERROR] Signing failed. Check the password and the certificate.
  pause
  exit /b 1
)

echo Verifying %OUT% ...
"%SIGNER%" -verify "%OUT%"
if errorlevel 1 (
  echo [ERROR] Verification failed.
  pause
  exit /b 1
)

echo.
echo Done: %OUT%
pause
exit /b 0
